#include<stdio.h>
int main() {

     /*int a;

     for (a=1; a<=10; a=a+4)
     {
        printf("*\n\n");
     }

     int i;
     for (i = 1; i <=3; i++)
     {
        printf("%d\n\n",i);
     }

     printf("Out of loop\n\n\n");
     
     printf("Print 1 to 100\n");

     for (int j = 1; j <=100; j++)
     {
        printf("%d\n",j);
     }


     printf("Printing even numbers\n");
     for (int e = 0; e <=100; e+2)
     {
        printf("%d\n",e);
     }*/


     printf("printing odd numbers\n");

     for (int o= 1; o<=100; o+2)
     {
        printf("%d\n",o);
     }



     return 0;
     
     
     
}