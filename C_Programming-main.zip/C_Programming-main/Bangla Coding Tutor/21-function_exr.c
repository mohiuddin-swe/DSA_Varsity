#include<stdio.h>

void print_message(){
    printf("Hello!! I am from inside a function\n");

}
int main() {

    print_message();

}