#include<stdio.h>
int main() {

    

    printf("My salary is %d taaka\n",100000);
    printf("%d + %d = %d\n", 10,5,200);
    printf("The hash character is: %c\n",'#');
    
    printf("My height: %f feet and weight: %d kg.\n",5.10,60);
     
    int x=15;
    int y=20;
    printf("Final value of x is: %d\n",x);

    x=x*y-20;
    printf("Final value of x is: %d\n",x);


    return 0;
}