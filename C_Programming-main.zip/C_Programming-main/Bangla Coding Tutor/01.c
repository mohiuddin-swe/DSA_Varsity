#include<stdio.h>

int main() {
    
    //all your code here
    
    printf("\tMy name is Md Mohiuddin\n");
    printf("\tThis is my first C program\n");
    printf("\tName:\tMohiuddin\n");
    printf("\tCountry:\t Bangladesh\n\n");
    printf("*\n");
    printf("**\n");
    printf("***\n");
    printf("****\n");
    printf("*****\n");
    printf("******\n");
    printf("*******\n");
    printf("********\n");



    return 0;
}