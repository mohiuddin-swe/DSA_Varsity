#include<stdio.h>
int main (){

    int x=3;

    switch(x){

        case 1:
        printf("Value is: 1\n");
        break;

        case 2:
        printf("value is : 2\n");
        break;

        case 3:
        printf("value is : 3\n");
        break;

        case 4:
        printf("value is : 4\n");
        break;

        default:
        printf("value is: unknown\n");

        return 0;
    }
}