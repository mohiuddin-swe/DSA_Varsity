#include<stdio.h>
int main(){

     printf("Size of integer in my computer: %d\n\n",sizeof(int));
    printf("float size: %d\n",sizeof(float));
    printf("double size: %d\n",sizeof(double));
    


     //Float -single precision floating number - 4 byte
    //Double -double precision flaoting point number -8 byte
    return 0;

   


}