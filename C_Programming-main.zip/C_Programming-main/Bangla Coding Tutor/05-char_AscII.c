#include<stdio.h>
int main(){
    char first = 'M',second ='U',third= 'K';
    printf("%c%c%c\n\n",first,second,third);
    char my_char;
    my_char = 'k';
    my_char = '3';
    printf("%c\n\n\n\n",my_char);

    char x ='A';
    printf("%c\n\n",x);
    printf("%d\n",x);

    int a =65,b=66,c=77;

    printf("%c%c%c",a,b,c);

/*ASCII Code\ Value:

   ASCII stands for American Standard Code for Information Interchange
   
   Char -Code(int)

   space -32
   A     -65
   a     -97
   */

    return 0;
}