#include<stdio.h>
#include<math.h>
main()
{
    float a=4.1;
    printf("Ceil value is %f\n",ceil(a));
    printf("Floor value is %f",floor(a));
}
