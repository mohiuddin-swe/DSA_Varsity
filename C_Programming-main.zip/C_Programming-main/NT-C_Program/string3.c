int main()
{
char address[30];

gets(address);
puts(address);
}
