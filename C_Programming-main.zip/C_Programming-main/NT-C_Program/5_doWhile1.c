// Program to add numbers until the user enters zero

#include <stdio.h>
int main() {
  //double number, sum =0;
  int num=0;

  // the body of the loop is executed at least once
  do {
    printf("The number is %d",num);
    //scanf("%lf", &number);
    //sum += number;//sum=sum+number
  }
  while(number != 0);

  //printf("Sum = %.2lf",sum);

  return 0;

}
