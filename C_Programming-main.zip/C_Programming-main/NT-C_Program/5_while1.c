int main()
{
   int i=1, j=1;
   while (i <= 3 || j <= 4)
   {

	i++;
	j++;
	printf("%d %d\n",i, j);

   }
   return 0;
}
