#include <stdio.h>
int main() {
int language;
scanf("%d",&language);
  switch (language) {
  case 1:
    printf("C#\n");
    break;
  case 2:
    printf("C\n");
    break;
   case 10:
    printf("C++\n");
    break;
    case 4:
    printf("C++\n");
    break;
  default:
    printf("Other programming language\n");}}
