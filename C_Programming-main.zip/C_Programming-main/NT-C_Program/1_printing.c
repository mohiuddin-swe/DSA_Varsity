#include <stdio.h>
int main() {
   // printf() displays the string inside quotation
   printf("Hello, World!\n");
   printf("This is Nusrat\n");
   return 0;
}
