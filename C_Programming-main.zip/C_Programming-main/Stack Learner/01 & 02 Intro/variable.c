#include <stdio.h>

int abc = 100;
int main()
{
    // int var = 55;
    // printf("var + 5 = %d\n", var + 5);
    // printf("var - 5 = %d\n", var - 5);
    // printf("var * 5 = %d\n", var * 5);
    // printf("var / 5 = %d\n", var / 5);
    // printf("var = %d\n", var);

    int a = 50;
    int b = 30;

    int c;
    c = 500;
    c = 100;
    printf("%d\n", c);
    
    printf("%d + %d = %d\n", a, b, a + b);
    printf("%d - %d = %d\n", a, b, a-b);
    printf("%d * %d = %d\n", a, b, a*b);
    printf("%d / %d = %d\n", a, b, a/b);
    printf("%d\n", abc);
    return 0;
}

// Variable name also called as Identifier

// Scope
// Local Variable, Global Variable

// Memory Life Time
// Static, Automatic

// External Variable

// Define A Variable
// Declare A Variable