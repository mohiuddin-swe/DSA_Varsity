#include <stdio.h>

int main() {

    printf("My Name is \tHM Nayem\n");
    printf("I have a Channel Called Twinkle Cats\n");
    printf("This Channel is Not About Cats,\nThis is about learning Programming for cats\n");

    printf("%d\n", 5 + 10);
    printf("%d\n", 15 - 10);
    printf("%d\n", 5 * 10);
    printf("%d\n", 50 / 10);
    return 0;
}