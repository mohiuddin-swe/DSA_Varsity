#include <stdio.h>

int main() {
    const float PI = 3.1416f;
    printf("%f\n", PI);
    return 0;
}