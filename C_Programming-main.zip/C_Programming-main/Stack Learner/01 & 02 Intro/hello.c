#include <stdio.h>

int main() {
    printf("Hello World");
    printf("\n");
    return 0;
}

/**
 * step 1 - Editing
 * step 2 - Compiling
 * step 3 - Linking
 * setp 4 - Executing
 */