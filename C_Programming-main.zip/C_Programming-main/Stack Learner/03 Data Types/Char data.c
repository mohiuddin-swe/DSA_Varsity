#include<stdio.h>
int main() {

    //Char - %c 
    char a = 65;
    printf("Char - %c\n",a);
    char b = 'B'+ 2;
    printf("Char - %c\t%d",b,b);

return 0;
}