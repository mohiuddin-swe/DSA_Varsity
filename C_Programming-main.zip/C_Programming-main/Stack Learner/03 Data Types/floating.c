#include<stdio.h>
int main () {
    
    //float - %f
    float f= 489.123F;
    printf("Float - %f\n ", f);

    //double - %lf
    double d=47789.56;
    printf ("Double - %lf\n", d);

    //Long double - %lf
    long double ld = 7854554132.565;
    printf("Long double - %lf\n\n", ld);

    printf("Program is end");


    return 0;

}