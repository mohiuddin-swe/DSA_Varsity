#include<stdio.h>
int main(){
    int i=1;
    while(i<=500){
        printf("I = %d\n",i);

        i++;
    }

    return 0;
}