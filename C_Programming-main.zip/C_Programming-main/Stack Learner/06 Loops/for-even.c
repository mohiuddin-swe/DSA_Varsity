#include<stdio.h>
int main(){
    int i;
    for(i=2;i<=100;i+=2){
        printf("%d is a Even number\n",i);
    }

    return 0;
}