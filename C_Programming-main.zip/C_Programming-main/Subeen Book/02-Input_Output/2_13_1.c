
#include <stdio.h>

int main()
{
    char ch = 'T';
    printf("The first letter of my name is:  %c\n", ch);


    return 0;

}
