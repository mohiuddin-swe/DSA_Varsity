
#include <stdio.h>

int main ()

{
    int a, b, sum;
    a = 60;
    b = 50;
    sum = a + b;

    printf ("Sum is %d|", sum);

    return 0;
}
