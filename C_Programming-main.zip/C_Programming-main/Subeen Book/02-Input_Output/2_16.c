
#include <stdio.h>

int main()
{
    //test program - comment 1
    
    printf("Hello");
    
    /* We have printed Hello,
    now we shall print World.
    Note that this is multi-line comment */
    
    printf("World");

    return 0;

}
