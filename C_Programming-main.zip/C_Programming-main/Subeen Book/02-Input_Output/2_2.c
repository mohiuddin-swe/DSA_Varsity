
#include <stdio.h>

int main ()
{
    int a, b, sum;

    a = 50;
    b = 60;
    sum = a + b;

    printf("Sum is %d", sum);

    return 0;
}
