
#include <stdio.h>

int main ()
{
    int a, b, sum;

    scanf("%d", &a);
    scanf("%d", &b);

    sum = a + b;

    printf("Sum is: %d\n", sum);


    return 0;
}
