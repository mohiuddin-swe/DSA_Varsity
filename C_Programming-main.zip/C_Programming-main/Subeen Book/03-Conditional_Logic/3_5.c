
#include <stdio.h>

int main()
{
    int number = 12;

    if (number > 10)
    {
        printf("The number is greater than Ten\n");
    }
    
    return 0;
}
