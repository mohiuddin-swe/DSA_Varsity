
#include <stdio.h>

int main()

{
    int n;
    n = -56;
    
    if (n < 0)
    {
        printf("The number is negative\n");
    }
    else 
    {
        printf("The number is positive\n");
    }


    return 0;
}
