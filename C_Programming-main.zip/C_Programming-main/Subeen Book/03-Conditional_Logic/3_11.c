
#include <stdio.h>
int main()
{
    int num = 5;

    if (num >= 1 || num <= 10)
    {
        printf("YES\n");
    }
    else 
    {
        printf("NO\n");
    }
    
    return 0;
}
