
#include <stdio.h>

int main()
{
    int n;

    n = 15;

    if (n >= 0)
    {
        printf("The number is positive\n");
    }
    else 
    {
        printf("The number is negative\n");
    }

    return 0;

}
