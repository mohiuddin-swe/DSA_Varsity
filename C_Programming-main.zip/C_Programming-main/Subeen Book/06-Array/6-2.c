#include<stdio.h>
int main () {

    int my_arr[10];

    printf("%d\n", my_arr[0]);
    printf("%d\n",my_arr[9]);

    return 0;
}