#include<stdio.h>
int main() {

    int my_arr[10]={5,10,15,20};

    printf("%d, %d\n", my_arr[0],my_arr[9]);

    return 0;
}