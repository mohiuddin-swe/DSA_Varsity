#include<stdio.h>
int main () {

    int my_arr[10]={5,10,15,20,25,30,35,40,45,50};

    printf("%d\n", my_arr[0]);
    printf("%d\n",my_arr[9]);

    return 0;
}