
#include <stdio.h>

int main ()
{
    printf("1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n");

    return 0;
}
