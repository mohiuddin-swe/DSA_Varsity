
#include <stdio.h>

int main ()
{
    int n = 1;
    while (1)
    {
        printf("%d",n);
    }

    return 0;

}
