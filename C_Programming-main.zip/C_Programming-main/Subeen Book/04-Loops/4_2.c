
#include <stdio.h>
int main ()
{
    int n = 1;
    
    while(n <= 60)   
    {
        printf("%d\n", n);
        n++;
    }

    return 0;
}
