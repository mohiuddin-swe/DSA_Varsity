
#include <stdio.h>

int main ()
{
    char country [] = { 'B', 'a', 'n', 'g', 'l', 'a', 'd', 'e', 's', 'h', ' \0', 'i', 's', ' ', 'm', 'y', ' ', 'c', 'o', 'u', 'n', 't', 'r', 'y', '\0'  };

    printf("%s\n", country);

    return 0;
}
