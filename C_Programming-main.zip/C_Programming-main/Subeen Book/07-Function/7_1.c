
#include <stdio.h>

int main ()

{
    double a, b, c;
    a = 2.5;
    b = 2.5;
    c = a + b;
    printf("%lf\n", c);

    return 0;
}
