#include<stdio.h>
int main (){
    int i,n,arr[30];
    printf("how many element you want to insert\n");
    scanf("%d",&n);

    printf("Insert %d no of element",n);

    for (i = 0; i < n; i++)
    {
        scanf("%d",& arr[i]);
    }
    
}